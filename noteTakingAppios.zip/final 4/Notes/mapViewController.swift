//
//  mapViewController.swift
//  Notes
//
//  Created by Sidharth Mehta on 19/11/19.
//  Copyright © 2019 Apple Developer. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class mapViewController: UIViewController,CLLocationManagerDelegate {
    @IBOutlet weak var mapv: MKMapView!
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
       self.locationManager.requestWhenInUseAuthorization()
             
             if CLLocationManager.locationServicesEnabled() {
                 
                 locationManager.delegate = self
                 locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
                 locationManager.startUpdatingLocation()
             }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        let userLocation = locations.last
        let viewRegion = MKCoordinateRegionMakeWithDistance((userLocation?.coordinate)!, 600, 600)
        self.mapv.setRegion(viewRegion, animated: true)
    }
    
    @IBAction func back(_ sender: Any) {
        let isPresentingInAddFluidPatientMode = presentingViewController is UINavigationController
               
               if isPresentingInAddFluidPatientMode {
                   dismiss(animated: true, completion: nil)
                   
               }
               
               else {
                   navigationController!.popViewController(animated: true)
                   
               }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
