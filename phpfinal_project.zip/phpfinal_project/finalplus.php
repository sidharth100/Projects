<?php
date_default_timezone_set('America/Toronto');
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$message = "";
$date = date('d, M, Y h:i A', time());
//$i = $_GET['count'];
try {

      $conn = new PDO("mysql:host=$servername;dbname=registration", $username, $password);
      $conn-> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    }
catch (PDOException $error)
    {
        $message = $error->getMessage();
    }
 $query = "SELECT * FROM options WHERE CAT_ID = '1' ";
    $stmt =$conn->prepare($query);

    $stmt->execute();



    $correct = [];

    $userans = [];
    foreach ($stmt as $row)
     {
     array_push($correct,''.$row['ANS'].'');

      array_push($userans,''.$row['USERANSWER'].'');

    }
    $right = 0;
    $wrong = 0;
    for ($i=0; $i <count($correct) ; $i++) {
    	if ($correct[$i]==$userans[$i]) {
    		$right++;
    	}
    	else
    	{
    		$wrong++;
    	}
    }
    if ($right<3) {
      header("location:./fail.php?");

    }

    $reg_id=$_SESSION['reg'];
    $FIRST_NAME = $_SESSION['user'];
    $cat = 2;
    $correct=$right;
    $testdate =$date;

        $query= "INSERT INTO history(reg_id,First_Name,CAT_ID,correct,TEST_DATE) VALUES(:reg_id,:FIRST_NAME,:cat,:correct,:testdate) ";
        $stmt =$conn->prepare($query);
        $stmt->bindParam(':reg_id',$reg_id);
        $stmt->bindParam(':FIRST_NAME',$FIRST_NAME);
        $stmt->bindParam(':cat',$cat);
        $stmt->bindParam(':correct',$correct);
        $stmt->bindParam(':testdate',$testdate);
        $stmt->execute();



$query = "Delete  FROM options  ";
    $stmt =$conn->prepare($query);

    $stmt->execute();
?>
<!DOCTYPE html>
<html>
  <head>
<style>
button
{
  margin-top: 10px;
  height: 50px;
  width:100px;
  margin-bottom: 10px;
}
#certi
{
  margin-left: 190px;
  background-size: cover;;
}
@media print {
      button * {
          visibility: hidden; // part to hide at the time of print
          -webkit-print-color-adjust: exact !important; // not necessary use
             if colors not visible
      }

      #logout1
      {
        visibility: hidden !important; // To hide

      }
      #printBtn {
          visibility: hidden !important; // To hide
      }
      #backw{
        visibility: hidden !important; // To hide

      }
      body * {
          visibility: visible; // Print only required part
          text-align: left;
          -webkit-print-color-adjust: exact !important;
      }
  }
</style>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body background="">
    <a href="welcome.html"><button type="submit" name="back" id="backw">HOME</button></a>
    <a href="login.html"><button type="submit" name="logout" id="logout1" value="LOGOUT">LOGOUT</button></a>
    <button type="button" onclick="window.print();" id="printBtn" name="button">Print</button>

    <div id="certi" style="background-image: url(cer1.jpg); width:800px; height:530px; padding:20px; text-align:center; border: 10px solid #787878">
<div style="width:750px; height:480px; padding:20px; text-align:center; border: 5px solid #787878">
<span style="font-size:50px; font-weight:bold">Certificate of Completion</span>
<br><br>
<span style="font-size:25px"><i>This is to certify that</i></span>
<br><br>
<span style="font-size:30px"><b><?php echo $_SESSION['user']; ?></b></span><br/><br/>
<span style="font-size:25px"><i>has completed the certification in</i></span> <br/><br/>
<span style="font-size:30px">JAVA</span> <br/><br/>
<span style="font-size:25px">with score of <br><b></b></span><h2><?php echo $right; ?>/10<br/><h2><br/>
<span style="font-size:25px"><i>dated</i></span><br>
<?php echo $date = date('d, M, Y h:i A', time()); ?>
<span style="font-size:30px"></span>
</div>
</div>




  </body>
</html>
