<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registration";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//Session Check For Admin
session_start();




if(isset($_POST['question'])){
$ques =  $_POST['question'];
$op1 =  $_POST['option-1'];
$op2 =  $_POST['option-2'];
$op3 =  $_POST['option-3'];
$op4 =  $_POST['option-4'];
$answer =  $_POST['correct-answer'];
$answer = str_replace("Option ","",$answer);
$category =  $_POST['selected-category'];
$sql_get_category_id = "SELECT CAT_ID FROM `categories` WHERE `CAT_NAME` = '$category'";
if ($res = mysqli_query($conn,$sql_get_category_id)){
if(mysqli_num_rows($res) == 1){
$c_id = mysqli_fetch_array($res)[0];
$sql = "INSERT INTO `questions`( `CAT_ID`, `QUESTIONS`, `CHOICE1`, `CHOICE2`, `CHOICE3`, `CHOICE4`,`Ans`) VALUES  ( '$c_id','$ques','$op1','$op2','$op3','$op4','$answer')";
if(mysqli_query($conn,$sql)){
echo("<script>alert('Question Added Successfully!')</script>");
}
else{
print($sql);
}
}
}

}
?>
<html>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="./style.css">
<script src="./menu.js"></script>

<!------ Include the above in your HEAD tag ---------->
<div id="throbber" style="display:none; min-height:120px;"></div>
<div id="noty-holder"></div>
<div id="wrapper">
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->

        <!-- Top Menu Items -->

<a href="admin.php"><button type="submit" name="logout" id="logout1" value="LOGOUT">BACK</button></a>
    <div id="page-wrapper">
        <div class="container-fluid">
            <!-- Page Heading -->
            <div class="row" id="main" >
                <div class="col-sm-12 col-md-12 well" id="content">
                    <div class="container">
  <h2>Add Question</h2>
  <form action="question.php" method="post">
    <div class="form-group">
      <label for="question">Question:</label>
      <input type="text" class="form-control" id="category" placeholder="Enter new question" name="question" required>
    </div>
 <div class="form-group">
      <label for="option-1">Option 1:</label>
      <input type="text" class="form-control" id="category" placeholder="Enter option" name="option-1" required>
    </div>
 <div class="form-group">
      <label for="option-2">Option 2:</label>
      <input type="text" class="form-control" id="category" placeholder="Enter option" name="option-2" required>
    </div>
 <div class="form-group">
      <label for="option-3">Option 3:</label>
      <input type="text" class="form-control" id="category" placeholder="Enter option" name="option-3" required>
    </div>
 <div class="form-group">
      <label for="option-4">Option 4:</label>
      <input type="text" class="form-control" id="category" placeholder="Enter option" name="option-4" required>
    </div>
 <div class="form-group">
      <label for="sel1">Correct Answer:</label>
      <select class="form-control" id="sel1" name="correct-answer" required>
        <option>Option 1</option>
        <option>Option 2</option>
        <option>Option 3</option>
        <option>Option 4</option>
      </select>
 </div>
 <div class="form-group">
      <label for="sel1">Select Category:</label>
      <select class="form-control" id="sel1" name="selected-category">
   <?php
 $sql_get_options = "SELECT * FROM categories";
 if ($res = mysqli_query($conn,$sql_get_options)){
while($list = mysqli_fetch_assoc($res)){
$category = $list['CAT_NAME'];
echo("<option>$category</option>");
}
}

 ?>

      </select>
 </div>
    <button type="submit" class="btn btn-primary" name="sub">Submit</button>
  </form>
</div>

                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
</div><!-- /#wrapper -->
</html>
