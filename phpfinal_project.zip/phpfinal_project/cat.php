<?php

echo "<table style='border: solid 2px black;'>";
echo "<tr><th>CAT_Id</th><th>CAT_NAME</th></tr>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}



$servername = "localhost";
$username = "root";
$password = "";
$message = "";
try {

      $conn = new PDO("mysql:host=$servername;dbname=registration", $username, $password);
      $conn-> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

      $query = "SELECT * from categories";
      $stmt =$conn->prepare($query);

      $stmt->execute();
      $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
      foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
          echo $v;
    }
  }
catch (PDOException $error)
    {
        $message = $error->getMessage();
    }

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body background="bg7.jpeg">
    <a href="admin.php"><button type="submit" name="logout" id="logout1" value="LOGOUT">BACK</button></a>
  </body>
</html>
