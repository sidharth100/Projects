<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$message = "";
$i = $_GET['count'];
try {

      $conn = new PDO("mysql:host=$servername;dbname=registration", $username, $password);
      $conn-> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    }
catch (PDOException $error)
    {
        $message = $error->getMessage();
    }
      if ($i<9) {
        # code...

     $query = "SELECT * FROM questions WHERE CAT_ID = '2' order by rand() limit 10";
    $stmt =$conn->prepare($query);

    $stmt->execute();
    $questionid = [];
    $catid = [];
    $question = [];
    $correct = [];
    $option1 = [];
    $option2 = [];
    $option3 = [];
    $option4 = [];
    foreach ($stmt as $row)
     {
     array_push($correct,''.$row['Ans'].'');
      array_push($questionid,''.$row['QUE_ID'].'');
      array_push($catid,''.$row['CAT_ID'].'');
      array_push($question,''.$row['QUESTIONS'].'');
      array_push($option1,''.$row['CHOICE1'].'');
      array_push($option2,''.$row['CHOICE2'].'');
      array_push($option3,''.$row['CHOICE3'].'');
      array_push($option4,''.$row['CHOICE4'].'');

    }
    if(isset($_POST['answer']))
    {
       $queid =$_POST['queid'];
    if(isset($_POST['next'])){
      $i = $i + 1;
      $answer = $_POST['answer'];
      $corrans = $_POST['correct'];
    $categoryid = $catid[$i];
    echo($categoryid);
    echo($queid);
    echo($answer);

    $query = "INSERT INTO options(QUE_ID,CAT_ID,USERANSWER,ANS) VALUES(:queid,:categoryid,:answer,:corrans) ";
    $stmt =$conn->prepare($query);
    $stmt->bindParam(':queid',$queid);
    $stmt->bindParam(':categoryid',$categoryid);
    $stmt->bindParam(':answer',$answer);
    $stmt->bindParam(':corrans',$corrans);
    $stmt->execute();
      //header("location: ./test1.php?count=".$i);
    }

    header("location: ./test2.php?count=".$i);
    include('test2.html');


  }
   }

    else
    {

      header("location: ./finalplus.php");
    }


include('test2.html');

  ?>
