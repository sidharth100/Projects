<?php

session_start();
$servername = "localhost";
$username = "root";
$password = "";
$EMAIL = $_POST['uemail'];
$PASSWORD = $_POST['psw'];
$message = "";
try {

      $conn = new PDO("mysql:host=$servername;dbname=registration", $username, $password);
      $conn-> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    }
catch (PDOException $error)
    {
        $message = $error->getMessage();
    }

if(isset($_POST["log"]))
{
  if(empty($_POST["uemail"]) || empty($_POST["psw"]) )
  {
    $message = '<label>All fields are required</label>' ;
  }
  elseif(($_POST["uemail"]=="admin") && ($_POST["psw"])=="admin")
  {
    include("admin.php");
  }
  else
  {
    $query = "SELECT FIRST_NAME,LAST_NAME,reg_id FROM register WHERE EMAIL = :EMAIL AND PASSWORD = :PASSWORD ";
    $stmt =$conn->prepare($query);
    $stmt->bindParam(':EMAIL',$EMAIL);
    $stmt->bindParam(':PASSWORD',$PASSWORD);
    $stmt->execute();
    $count = $stmt->rowCount();
    if($count > 0)
    {
    //  $_SESSION["EMAIL"] = $_POST["EMAIL"];
    	$row = $stmt->fetch(PDO::FETCH_ASSOC);
         $_SESSION['user'] = $row['FIRST_NAME'];
         $_SESSION['reg'] = $row['reg_id'];
         $error3 = $_SESSION['user'];

      include("welcome.html");
    }
    else
    {

      $error2 = "Invalid username or password";
      include("login.html");

    }
  }
}


?>
