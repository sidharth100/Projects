<?php
$FIRST_NAME = $_POST['fname'];
$LAST_NAME = $_POST['lname'];
$EMAIL = $_POST['uemail'];
$PHONE = $_POST['phone'];
$ADDRESS = $_POST['addr'];
$PASSWORD = $_POST['psw'];

$servername = "localhost";
$username = "root";
$password = "";
$conn = new PDO("mysql:host=$servername;dbname=registration", $username, $password);

if (!filter_var($EMAIL, FILTER_VALIDATE_EMAIL)) {
  $error1 = "Invalid email format";
  include ("registrationpage.html");
}
elseif (!preg_match("/^[a-zA-Z ]*$/",$FIRST_NAME)) {
  $error1 = "Only letters and white space allowed";
  include ("registrationpage.html");
}
elseif (!preg_match("/^[a-zA-Z ]*$/",$LAST_NAME)) {
  $error1 = "Only letters and white space allowed";
  include ("registrationpage.html");
}
elseif(!preg_match("/^[0-9]{3}-[0-9]{4}-[0-9]{4}$/", $PHONE)) {
  $error1 = "Invalid phonenumber";
  include ("registrationpage.html");
}

else {



    $query = "SELECT * FROM register WHERE EMAIL = :EMAIL";
    $stmt =$conn->prepare($query);
    $stmt->bindParam(':EMAIL',$EMAIL);
    $stmt->execute();
    $count = $stmt->rowCount();
    if($count > 0)
    {
    //  $_SESSION["EMAIL"] = $_POST["EMAIL"];
      $error1 = "User Already exist";

      //echo "Already acquired";
      include("registrationpage.html");

      $stmt = null;
      $conn = null;
    }

    else {
    $stmt =$conn->prepare( "INSERT into register(FIRST_NAME,LAST_NAME,EMAIL,PHONE,ADDRESS,PASSWORD) values(:FIRST_NAME,:LAST_NAME,:EMAIL,:PHONE,:ADDRESS,:PASSWORD)");

    $stmt->bindParam(':FIRST_NAME',$FIRST_NAME);
    $stmt->bindParam(':LAST_NAME',$LAST_NAME);
    $stmt->bindParam(':EMAIL',$EMAIL);
    $stmt->bindParam(':PHONE',$PHONE);
    $stmt->bindParam(':ADDRESS',$ADDRESS);
    $stmt->bindParam(':PASSWORD',$PASSWORD);
    $stmt->execute();
    echo "Registration Successful";
    include('login.html');
  }
}
?>
