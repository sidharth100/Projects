<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
//$EMAIL = $_POST['uemail'];
//$PASSWORD = $_POST['psw'];
$message = "";
try {

      $conn = new PDO("mysql:host=$servername;dbname=registration", $username, $password);
      $conn-> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    }
catch (PDOException $error)
    {
        $message = $error->getMessage();
    }
include("welcome.html");
include("test1.html");
include("test2.html");

if (isset($_SESSION["EMAIL"]))
{
  echo '<h3>Welcome'.$_SESSION["EMAIL"].'</h3>';
}
else {
  header("login.php?count=0");
}

?>
