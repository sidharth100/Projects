<?php


?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
<style>
    button {
      background-color: #000;
      color: white;
      padding: 14px 20px;
      font-size: 15px;
      margin-top: 20px;
      border: none;
      cursor: pointer;
      width: 30%;

    }

    button:hover {
      opacity: 0.8;
    }
    img
    {
      height: 200px;
      width:200px;
    }

</style>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body background="bg7.jpeg">


    <a href="login.html"><input type="submit" name="logout" id="logout1" value="LOGOUT"></a>
    <center><h1>WELCOME ADMIN</h1></center>

    <center>
      <div class="imgcontainer">
        <img src="logo2.png" alt="test" class="test">
        <br><br>
        <a href="question.php"><button type="submit" name="que" id="button">Questions</button></a>

        <br>
<a href="cat.php"><button type="submit" name="cat" id="button">Categories</button></a><br>
      </div>


    </center>





  </body>
</html>
