<?php
$servername = "localhost";
$username = "root";
$password = "";
$EMAIL = $_POST['uemail'];
$PASSWORD = $_POST['psw'];
$message = "";
try {

      $conn = new PDO("mysql:host=$servername;dbname=registration", $username, $password);
      $conn-> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    }
catch (PDOException $error)
    {
        $message = $error->getMessage();
    }

    $query = "Delete  FROM options  ";
        $stmt =$conn->prepare($query);

        $stmt->execute();
        header("location:./login.html");

?>
