<!DOCTYPE html>
<html>
  <head>
<style>
h1{
  margin-top: 160px;
}
button
{
  margin-top: 10px;
  height: 50px;
  width:100px;
  margin-bottom: 10px;
}
#certi
{
  margin-left: 190px;
  background-size: cover;;
}
@media print {

      button * {
          visibility: hidden; // part to hide at the time of print
          -webkit-print-color-adjust: exact !important; // not necessary use
             if colors not visible
      }

      #logout1
      {
        visibility: hidden !important; // To hide

      }
      #printBtn {
          visibility: hidden !important; // To hide
      }
      #backw{
        visibility: hidden !important; // To hide

      }
      body * {
          visibility: visible; // Print only required part
          text-align: left;
          background:cer1.jpg;
          -webkit-print-color-adjust: exact !important;
      }
  }
</style>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body background="">
    <a href="welcome.html"><button type="submit" name="back" id="backw">HOME</button></a>
    <a href="login.html"><button type="submit" name="logout" id="logout1" value="LOGOUT">LOGOUT</button></a>


    <div id="certi"  style="background-image: url(cer3.jpg); width:800px; height:530px; padding:20px; text-align:center; border: 10px solid #787878">
<div style="width:750px; height:480px; padding:20px; text-align:center; border: 5px solid #787878">
  <center>
<h1>You failed the exam try again.</h1></center>
<span style="font-size:30px"></span>
</div>
</div>




  </body>
</html>
