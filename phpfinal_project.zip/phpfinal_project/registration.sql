-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 09, 2019 at 11:15 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `attempt`
--

CREATE TABLE `attempt` (
  `AT_Id` int(100) NOT NULL,
  `REG_ID` int(100) NOT NULL,
  `CAT_ID` int(100) NOT NULL,
  `QUE_ID` int(100) NOT NULL,
  `ANS_ID` int(100) NOT NULL,
  `TEST_DATE` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `CAT_ID` int(11) NOT NULL,
  `CAT_NAME` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`CAT_ID`, `CAT_NAME`) VALUES
(1, 'TEST1'),
(2, 'TEST2');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `reg_id` int(100) NOT NULL,
  `First_Name` varchar(100) NOT NULL,
  `CAT_ID` int(100) NOT NULL,
  `correct` int(100) NOT NULL,
  `TEST_DATE` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`reg_id`, `First_Name`, `CAT_ID`, `correct`, `TEST_DATE`) VALUES
(2, 'Sidharth', 1, 3, '09, Oct, 2019 03:19 PM'),
(2, 'Sidharth', 2, 0, '09, Oct, 2019 03:25 PM'),
(1, 'Vaibhav', 1, 1, '09, Oct, 2019 04:39 PM'),
(1, 'Vaibhav', 2, 0, '09, Oct, 2019 04:39 PM'),
(1, 'Vaibhav', 1, 7, '09, Oct, 2019 04:41 PM'),
(2, 'Sidharth', 1, 4, '09, Oct, 2019 05:10 PM');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `OP_ID` int(100) NOT NULL,
  `ANS` int(100) NOT NULL,
  `QUE_ID` int(100) NOT NULL,
  `CAT_ID` int(100) NOT NULL,
  `USERANSWER` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `QUE_ID` int(100) NOT NULL,
  `CAT_ID` int(100) NOT NULL,
  `QUESTIONS` varchar(200) NOT NULL,
  `CHOICE1` varchar(100) NOT NULL,
  `CHOICE2` varchar(100) NOT NULL,
  `CHOICE3` varchar(100) NOT NULL,
  `CHOICE4` varchar(100) NOT NULL,
  `Ans` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`QUE_ID`, `CAT_ID`, `QUESTIONS`, `CHOICE1`, `CHOICE2`, `CHOICE3`, `CHOICE4`, `Ans`) VALUES
(1, 1, 'A single line comment in C language source code can begin with', ';', ':', '/*', '//', 4),
(2, 1, 'What do the following statement defines-(int *ptr[10];)', 'ptr is a pointer to an array of 10 integer pointers.', 'ptr is a array of 10 pointers to integers', 'ptr is a array of 10 integer pointers', 'None of the above', 2),
(3, 1, 'What is a pointer?\r\n', 'A keyword used to create variables', 'A variable used to store address of an instruction', 'A variable used to store address of other variable', 'A variable used to store address of a structure', 3),
(4, 1, 'The library function strchr() finds the first occurrence of a substring in another string.', 'yes', 'Strstr()', 'strchr()', 'strnset()', 2),
(5, 1, 'Which of the following is a logical NOT operator?', '!', '&&', '&', 'All of the above', 1),
(6, 1, 'Which of the following header file can be used to define the NULL macro?', 'stddef.h, locale.h, math.h, stdlib.h, string.h', 'time.h, wchar.h, math.h, locale.h,', 'math.h', 'stdio.h, locale.h, stddef.h, stdlib.h, string.h,', 1),
(7, 1, 'Choose the function that is most appropriate for reading in a multi-word string?', 'strnset() ', 'scanf()', 'strchr()', 'gets()', 4),
(8, 1, 'Identify the incorrect file opening mode from the following.', 'r', 'w', 'x', 'a', 3),
(9, 1, ' How to round-off a value “5.77” to 6.0?', 'ceil(5.77)', 'round-off(5.77)', 'round-up(5.77)', 'floor(5.77)', 1),
(10, 1, 'The correct order of mathematical operators in mathematics and computer programming,', 'Addition, Subtraction, Multiplication, Division', 'Division, Multiplication, Addition, Subtraction', 'Multiplication, Addition, Division, Subtraction ', 'Mathematical operators can be done in any order', 2),
(11, 1, 'Identify the invalid constant used in fseek() function as ‘whence’ reference.', 'SEEK_SET', 'SEEK_CUR', 'SEEK_BEG', 'SEEK_END', 3),
(12, 1, 'Which scanf() statement will you use to scan a float value (a) and double value (b)?', 'scanf(\"%f %f\", &a, &b);', 'scanf(\"%lf % lf \", &a, &b);', 'scanf(\"%Lf %Lf\", &a, &b);', 'scanf(\"%f %lf\", &a, &b);', 4),
(13, 1, 'Suppose a,b,c are integer variables with values 5,6,7 respectively.  What is the value of the expression:\r\n   !((b+c)>(a+10))', '1', '6', '15', '0', 1),
(14, 1, 'Which of the following has a global scope in the program?', 'Formal parameters', 'Constants', 'Macros', 'Local variables', 3),
(15, 1, 'Which of the following statements about functions is false?', 'The main() function can be called recursively', 'Functions cannot return more than one value at a time', 'A function can have multiple return statements with different return values', 'The maximum number of arguments a function can take is 128', 4),
(16, 1, 'What is the range of double data type for a 16-bit compiler?', '-1.7e-328 to +1.7e-328', '-1.7e-348 to +1.7e-348', '-1.7e-308 to +1.7e-308', '-1.7e-328 to +1.7e-328', 3),
(17, 1, 'Which operator is used to check if a particular bit is on or off?', '&', '|', '!', '||', 1),
(18, 1, 'Out of the following declarations, which one is invalid?', 'short a = 10;', 'unsigned short b = 20;', 'long double c = 30;', 'long short d = 40;', 4),
(19, 1, 'Which of the following is treated as a real number by default?', 'float', 'long', 'double', 'long double', 3),
(20, 1, 'Which of the following in C is analogous to dictionaries in Python?', 'Linked lists', 'Templates', 'Arrays', 'Structures', 3),
(21, 2, '.A process that involves recognizing and focusing on the important characteristics of a situation or object   is known as:', 'Encapsulation', 'Polymorphism', 'Abstraction ', 'Inheritance', 3),
(22, 2, 'Which statement is true regarding an object?', 'An object is what classes instantiated are from', 'An object is an instance of a class', 'An object is a variable', ' An object is a reference to an attribute', 2),
(23, 2, 'In object-oriented programming, composition relates to\r\n', 'The use of consistent coding conventions', 'The organization of components interacting to achieve a coherent, common behavior', 'The use of inheritance to achieve polymorphic behavior', 'The use of data hiding to achieve polymorphic behavior', 2),
(24, 2, 'In object-oriented programming, new classes can be defined by extending existing classes. This is an   example of:', 'Encapsulation', 'Interface', 'Composition', 'Inheritance', 4),
(25, 2, 'Object-oriented inheritance models the', '“is a kind of” relationship', '“has a” relationship', '“want to be” relationship', '“contains” of relationship.', 1),
(26, 2, 'The wrapping up of data and functions into a single unit is called', 'Encapsulation', 'Abstraction', 'Polymorphism', 'None', 1),
(27, 2, 'What is jdk stand for', 'java development kit', 'java developer kit', 'java developed kit', 'None', 1),
(28, 2, 'In object-oriented programming, new classes can be defined by extending existing classes. This is an example of:', 'Encapsulation ', 'Interface ', 'Composition', 'Inheritance ', 4),
(29, 2, 'Given a class named student, which of the following is a valid constructor declaration for the class?', 'Student (student s) { }', 'Student student ( ) { }', 'Private final student ( ) { }', 'Static void student(){ }.', 1),
(30, 2, 'A package is a collection of', 'Classes', 'Interfaces ', 'Editing tools', 'Classes and interfaces', 4),
(31, 2, 'Basic Java language functions are stored in which of the following java package?', 'java.lang', 'java.io', 'java.net', 'java.util', 1),
(32, 2, 'Which of the following is a member of the java.lang package?', 'List', 'Queue', 'Math', 'Stack', 2),
(33, 2, 'Which of the following has a method names flush( )?', 'Input stream', 'Output Stream', 'Reader stream', 'Input reader stream', 2),
(34, 2, 'What is the fundamental unit of information of writer streams?', 'Characters', 'Bytes', 'Files', 'Records', 1),
(35, 2, 'What is the fundamental unit of information of writer streams?', 'java.io package', 'java.lang package', 'java.awt package', 'java.net.package', 1),
(36, 2, 'What is the return type of the method getID() defined in AWTEvent', 'Int', 'Long', 'Object', 'Float', 1),
(37, 2, 'Which of the following events will cause a thread to die?', 'The method sleep( ) is called', 'The method wait( ) is called', 'Execution of the start( ) method ends', 'Execution of the run( ) method ends', 4),
(38, 2, 'Which one of these is a valid method declaration?', 'void method1', 'void method2()', 'void method3(void)', 'method4()', 2),
(39, 2, 'Which one of the following class definitions is a valid definition of a class that cannot be extended?', 'class Link { }', 'abstract class Link { }', 'native class Link { }', 'final class Link { }.', 4),
(40, 2, 'How restrictive is the default accessibility compared to public, protected, and private accessibility?', 'Less restrictive than public', 'More restrictive than public, but less restrictive than protected', 'More restrictive than protected, but less restrictive than private', 'More restrictive than private', 3),
(41, 1, 'What is int?', 'Data type', 'value', 'class', 'object', 1),
(42, 1, 'What is injkwdkwj?', 'Data type', 'value', 'class', 'object', 1);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `reg_id` int(11) NOT NULL,
  `FIRST_NAME` varchar(11) NOT NULL,
  `LAST_NAME` varchar(11) NOT NULL,
  `EMAIL` varchar(60) NOT NULL,
  `PHONE` decimal(10,0) NOT NULL,
  `ADDRESS` varchar(30) NOT NULL,
  `PASSWORD` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`reg_id`, `FIRST_NAME`, `LAST_NAME`, `EMAIL`, `PHONE`, `ADDRESS`, `PASSWORD`) VALUES
(1, 'Vaibhav', 'Dutt', 'vaibhavdutt14can@gmail.com', '4169301994', '36 hbhj hjhe', 'test'),
(2, 'Sidharth', 'Mehta', 'ask4sid@gmail.com', '4169301994', 'dhbksbd', 'hello'),
(3, 'Karan', 'N', 'karan@gmail.com', '4167683939', '34 efuebbe effee', 'welcome'),
(4, 'sid', 'm', 'sidharth@gmail.com', '4169301994', '12 gntnynyr', 'test2'),
(5, 'simran', 'th', 'simran@gmail.com', '4169301994', '32, Autumn Glen Circle', 'hello');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attempt`
--
ALTER TABLE `attempt`
  ADD PRIMARY KEY (`AT_Id`),
  ADD KEY `REG_ID` (`REG_ID`),
  ADD KEY `CAT_ID` (`CAT_ID`),
  ADD KEY `QUE_ID` (`QUE_ID`),
  ADD KEY `ANS_ID` (`ANS_ID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`CAT_ID`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD KEY `reg_id` (`reg_id`),
  ADD KEY `CAT_ID` (`CAT_ID`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`OP_ID`),
  ADD KEY `QUE_ID` (`QUE_ID`),
  ADD KEY `CAT_ID` (`CAT_ID`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`QUE_ID`),
  ADD KEY `CAT_ID` (`CAT_ID`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`reg_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attempt`
--
ALTER TABLE `attempt`
  MODIFY `AT_Id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `CAT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `OP_ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=487;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `QUE_ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attempt`
--
ALTER TABLE `attempt`
  ADD CONSTRAINT `attempt_ibfk_1` FOREIGN KEY (`REG_ID`) REFERENCES `register` (`reg_id`),
  ADD CONSTRAINT `attempt_ibfk_2` FOREIGN KEY (`CAT_ID`) REFERENCES `categories` (`CAT_ID`),
  ADD CONSTRAINT `attempt_ibfk_3` FOREIGN KEY (`QUE_ID`) REFERENCES `questions` (`QUE_ID`),
  ADD CONSTRAINT `attempt_ibfk_4` FOREIGN KEY (`ANS_ID`) REFERENCES `options` (`OP_ID`);

--
-- Constraints for table `history`
--
ALTER TABLE `history`
  ADD CONSTRAINT `history_ibfk_1` FOREIGN KEY (`reg_id`) REFERENCES `register` (`reg_id`),
  ADD CONSTRAINT `history_ibfk_2` FOREIGN KEY (`CAT_ID`) REFERENCES `categories` (`CAT_ID`);

--
-- Constraints for table `options`
--
ALTER TABLE `options`
  ADD CONSTRAINT `options_ibfk_1` FOREIGN KEY (`QUE_ID`) REFERENCES `questions` (`QUE_ID`),
  ADD CONSTRAINT `options_ibfk_2` FOREIGN KEY (`CAT_ID`) REFERENCES `categories` (`CAT_ID`);

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`CAT_ID`) REFERENCES `categories` (`CAT_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
