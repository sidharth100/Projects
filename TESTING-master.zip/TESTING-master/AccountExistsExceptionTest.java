package bankingapp.src.bankingApp;

import org.junit.rules.ExpectedException;

import static org.junit.jupiter.api.Assertions.*;

class AccountExistsExceptionTest {
    public ExpectedException thrown = ExpectedException.none();

}